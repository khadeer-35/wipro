package com.spring.core.SpringCore.CI;

public class Certification {
	public String name;

	public Certification(String name) {
		super();
		this.name = name;
	}

	@Override
	public String toString() {
		return "Certification [name=" + name + "]";
	}
	

}
