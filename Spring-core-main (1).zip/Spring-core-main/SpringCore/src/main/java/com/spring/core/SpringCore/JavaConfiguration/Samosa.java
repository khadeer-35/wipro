package com.spring.core.SpringCore.JavaConfiguration;

public class Samosa {
    public void display() {
    	System.out.println("Bro,I am not cheap,ohk");
    }
}
